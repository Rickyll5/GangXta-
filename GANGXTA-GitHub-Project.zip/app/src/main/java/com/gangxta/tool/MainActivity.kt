package com.gangxta.tool

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 15, 20)
    private val panel = Color.rgb(27, 30, 38)
    private val accent = Color.rgb(230, 55, 65)
    private lateinit var status: TextView
    private lateinit var targetLabel: TextView
    private var selectedTarget = "Cabeça"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val title = TextView(this).apply {
            text = "GANGXTA"
            textSize = 30f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 4)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "ADVANCED AIM TRAINER"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 26)
        }
        content.addView(subtitle)

        content.addView(section("SELEÇÃO DE ALVO"))
        targetLabel = TextView(this).apply {
            text = "Alvo selecionado: $selectedTarget"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 16, 14, 16)
            setBackgroundColor(panel)
        }
        content.addView(targetLabel)

        val targets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("Cabeça", "Pescoço", "Peito", "Todos").forEach { target ->
            val button = Button(this).apply {
                text = target
                textSize = 10f
                setOnClickListener {
                    selectedTarget = target
                    targetLabel.text = "Alvo selecionado: $selectedTarget"
                }
            }
            targets.addView(button, LinearLayout.LayoutParams(0, 54, 1f).apply {
                setMargins(2, 8, 2, 12)
            })
        }
        content.addView(targets)

        content.addView(section("TREINO DE PRECISÃO"))
        val sensitivityValue = TextView(this).apply {
            text = "Sensibilidade de treino: 50"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(4, 12, 4, 4)
        }
        content.addView(sensitivityValue)

        val slider = SeekBar(this).apply {
            max = 100
            progress = 50
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    sensitivityValue.text = "Sensibilidade de treino: $value"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        content.addView(slider)

        val start = Button(this).apply {
            text = "INICIAR TREINO"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                status.text = "Treino iniciado — alvo: $selectedTarget"
            }
        }
        content.addView(start, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 54
        ).apply { setMargins(0, 22, 0, 8) })

        status = TextView(this).apply {
            text = "Estado: pronto"
            textSize = 14f
            setTextColor(Color.GREEN)
            setPadding(8, 14, 8, 14)
            gravity = Gravity.CENTER
        }
        content.addView(status)

        content.addView(section("PROTEÇÃO DO APLICATIVO"))
        val protection = TextView(this).apply {
            text = "Integridade básica: ativa\\nEste módulo protege apenas a instalação do GANGXTA."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(14, 16, 14, 16)
            setBackgroundColor(panel)
        }
        content.addView(protection)

        val footer = TextView(this).apply {
            text = "GANGXTA v1.0 • Ferramenta independente de treino"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 10)
        }
        content.addView(footer)

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun section(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(accent)
        setPadding(2, 20, 2, 10)
        setTypeface(null, android.graphics.Typeface.BOLD)
    }
}
